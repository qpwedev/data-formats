query-1-1.jq - Select all faculty names in English
query-1-2.jq - Courses names in english that attends Karel Matej Cech-Chod
query-1-3.jq - Select all teachers that taught some course which are younger that have birth date greater than 1957-09-10
query-1-4.jq - List all students that studies at CTU on FNSPE